/* SI-BARISAN - logika aplikasi: tema, slider, penilaian mandiri, bukti dukung, daftar penilaian, login. */
(function () {

    /*=============== HELPERS ===============*/
    var $ = function (s, r) {
        return (r || document).querySelector(s)
    },
        $$ = function (s, r) {
            return [].slice.call((r || document).querySelectorAll(s))
        };

    document.documentElement.classList.add('js');

    /*=============== SHOW MENU ===============*/
    var menu = $('#nav-menu');

    $('#nav-toggle').onclick = function () {
        menu.classList.add('show')
    };

    $('#nav-close').onclick = function () {
        menu.classList.remove('show')
    };

    $$('.nav__link').forEach(function (a) {
        a.onclick = function () {
            menu.classList.remove('show')
        }
    });

    /*=============== DARK LIGHT THEME ===============*/
    var root = document.documentElement, tb = $('#theme-button');

    function setTheme(t) {
        root.dataset.theme = t;
        tb.firstChild.nextSibling ? 0 : 0;
        tb.innerHTML = '<svg class="i"><use href="#' + (t === 'dark' ? 'sun' : 'moon') + '"/></svg>'
    }

    var saved = null;

    try {
        saved = localStorage.getItem('theme')
    } catch (e) {}

    setTheme(saved || 'light');

    tb.onclick = function () {
        var t = root.dataset.theme === 'dark' ? 'light' : 'dark';
        setTheme(t);

        try {
            localStorage.setItem('theme', t)
        } catch (e) {}
    };

    /*=============== SLIDERS ===============*/
    $$('.slider').forEach(function (s) {
        var tr = $('.slider__track', s), n = $$('.slide', s).length, i = 0, tm, x0 = null;

        function go(k) {
            i = (k + n) % n;
            tr.style.transform = 'translateX(-' + i * 100 + '%)'
        }

        function play() {
            var d = +s.dataset.auto;

            if (d && !matchMedia('(prefers-reduced-motion:reduce)').matches) {
                clearInterval(tm);

                tm = setInterval(function () {
                    go(i + 1)
                }, d)
            }
        }

        $('.prev', s).onclick = function () {
            go(i - 1);
            play()
        };

        $('.next', s).onclick = function () {
            go(i + 1);
            play()
        };

        s.onmouseenter = function () {
            clearInterval(tm)
        };

        s.onmouseleave = play;

        s.addEventListener('touchstart', function (e) {
            x0 = e.touches[0].clientX
        }, { passive: true });

        s.addEventListener('touchend', function (e) {
            if (x0 === null) return;
            var d = e.changedTouches[0].clientX - x0;

            if (Math.abs(d) > 40) {
                go(i + (d < 0 ? 1 : -1));
                play()
            }

            x0 = null
        });

        play();
    });

    /*=============== SCROLL: HEADER, SCROLL UP, ACTIVE LINK ===============*/
    var hd = $('#header'),
        up = $('#scroll-up'),
        secs = $$('main section[id]'),
        links = $$('.nav__link');

    function onScroll() {
        var y = window.scrollY;
        hd.classList.toggle('scrolled', y > 40);
        up.classList.toggle('show', y > 350);
        var cur = secs[0].id;

        secs.forEach(function (s) {
            if (y + 120 >= s.offsetTop) cur = s.id
        });

        links.forEach(function (a) {
            a.classList.toggle('active-link', a.getAttribute('href') === '#' + cur)
        });
    }

    addEventListener('scroll', onScroll, { passive: true });
    onScroll();

    /*=============== SCROLL REVEAL ANIMATION ===============*/
    var rv = $$('.rv');

    if ('IntersectionObserver' in window) {
        var io = new IntersectionObserver(function (es) {
            es.forEach(function (e) {
                if (e.isIntersecting) {
                    e.target.classList.add('in');
                    io.unobserve(e.target)
                }
            })
        }, { threshold: .12 });

        rv.forEach(function (e) {
            io.observe(e)
        });
    } else rv.forEach(function (e) {
        e.classList.add('in')
    });

    /*=============== ASSESSMENT DATA (MINIMUM STANDARDS) ===============*/
    var G = [
        [
            "BARISAN",
            [
                [
                    "Bersih",
                    "assets/img/BERSIH1.jpeg",
                    [
                        "Tempat sampah terpilah di area strategis",
                        "Jadwal kebersihan dan petugas ditunjuk",
                        "Tidak ada sampah berserakan",
                        "Toilet dan tempat wudu bersih dan berfungsi",
                        "Drainase tidak tersumbat",
                        "Pengurangan plastik sekali pakai"
                    ]
                ],
                [
                    "Asri",
                    "assets/img/EKOTEOLOGI.jpeg",
                    [
                        "Halaman dan area terbuka tertata",
                        "Taman atau tanaman hias",
                        "Barang dan arsip tersimpan rapi",
                        "Tidak ada sudut kumuh"
                    ]
                ],
                [
                    "Rindang",
                    "assets/img/RINDANG.jpeg",
                    [
                        "Pohon peneduh atau tanaman pot",
                        "Biopori atau sumur resapan",
                        "Tanaman dipelihara berkala",
                        "Program tanam pohon min. 1x setahun"
                    ]
                ],
                [
                    "Indah",
                    "assets/img/INDAH.jpeg",
                    [
                        "Bangunan dan fasilitas terawat",
                        "Papan nama dan penunjuk arah jelas",
                        "Media pesan lingkungan dan ekoteologi",
                        "Penataan ruang estetis dan serasi"
                    ]
                ],
                [
                    "Sehat",
                    "assets/img/SEHAT.jpeg",
                    [
                        "Air bersih layak",
                        "Sirkulasi udara dan cahaya memadai",
                        "Kawasan tanpa rokok",
                        "Bebas genangan dan jentik",
                        "Sarana cuci tangan",
                        "Asrama, dapur, kantin bersih (bila ada)"
                    ]
                ],
                [
                    "Aman",
                    "assets/img/AMAN1.jpeg",
                    [
                        "APAR masih berlaku",
                        "Jalur evakuasi dan titik kumpul",
                        "Prosedur kesiapsiagaan bencana disosialisasikan",
                        "Pohon, bangunan, listrik diperiksa berkala",
                        "Drainase mencegah banjir"
                    ]
                ],
                [
                    "Nyaman",
                    "assets/img/NYAMAN.jpeg",
                    [
                        "Ruang layanan, kerja, belajar nyaman",
                        "Penghematan energi",
                        "Penghematan air",
                        "Akses disabilitas dan lansia"
                    ]
                ]
            ]
        ],
        [
            "SIPAKAINGE",
            [
                [
                    "Sipakatau",
                    "",
                    [
                        "Aksi BARISAN diikuti seluruh warga 1x/bulan",
                        "Aksi melibatkan perempuan, lansia, disabilitas, murid",
                        "Fasilitas dapat dipakai warga saat darurat"
                    ]
                ],
                [
                    "Sipakalebbi",
                    "",
                    [
                        "Apresiasi perilaku peduli lingkungan",
                        "Min. 80% pohon tanam tetap hidup",
                        "Plastik, listrik, air menurun dari kondisi awal"
                    ]
                ],
                [
                    "Sipakainge",
                    "",
                    [
                        "Pesan SIPAKAINGE 2x/bulan",
                        "Ekoteologi masuk layanan utama 1x/bulan",
                        "Praktik baik dibagikan 1x/tahun"
                    ]
                ],
                [
                    "Siri' na Pacce",
                    "",
                    [
                        "Ikrar ditandatangani dan dipasang",
                        "Simulasi kesiapsiagaan bencana",
                        "Aksi solidaritas korban bencana"
                    ]
                ]
            ]
        ],
        [
            "Kolaborasi",
            [
                [
                    "Kolaborasi",
                    "",
                    [
                        "Kerja sama tertulis dengan pihak luar Kemenag",
                        "Kegiatan kolaboratif tiap semester",
                        "Dukungan nyata yang sah dan dapat diverifikasi"
                    ]
                ]
            ]
        ],
        [
            "Tata Kelola dan Pelaporan",
            [
                [
                    "Tata Kelola",
                    "",
                    [
                        "SK Tim Pelaksana",
                        "Rencana kegiatan masuk anggaran",
                        "Penilaian diajukan tepat waktu",
                        "Rencana perbaikan maks. 1 bulan",
                        "Laporan semester tepat waktu",
                        "Bukti lengkap dan dapat diakses"
                    ]
                ]
            ]
        ]
    ];

    /*=============== STATE & SCORING ===============*/
    var st = {}, KEY = "si-barisan", mem = [], U = null;

    function na(g, u, i) {
        return g == 0 && u == 4 && i == 5 && !$("#as").checked
    }

    /*=============== EVIDENCE RULES ===============*/
    var OK = /\.(jpe?g|png|webp|gif|pdf|docx?|xlsx?)$/i, MAXB = 5 * 1024 * 1024, MAXF = 5;

    function isImg(f) {
        return /^image\//.test(f.type) || /\.(jpe?g|png|webp|gif)$/i.test(f.name)
    }

    function fok(f) {
        return!isImg(f) || (!!f.tgl && f.lok.trim().length > 1)
    }

    function evOK(x) {
        return x.f.some(fok) || x.o.trim().length >= 10
    }

    function eff(g, u, i) {
        var x = st[g + "." + u + "." + i];
        return x.s > 0 && !evOK(x) ? 0 : x.s
    }

    function sz(n) {
        return n < 1048576 ? Math.max(1, Math.round(n / 1024))
            + " KB": (n / 1048576).toFixed(1)
            + " MB"
    }

    function flist(k) {
        var x = st[k], el = document.getElementById("f" + k);
        if (!el) return;

        el.innerHTML = x.f.map(function (f, j) {
            var im = isImg(f);

            return '<li>'
                + (
                    im && f.url ? '<img src="'
                        + f.url
                        + '" alt="Pratinjau '
                        + esc(f.name)
                        + '">': '<span class="dc">'
                        + (im ? 'FOTO' : f.name.split(".").pop().slice(0, 4).toUpperCase())
                        + '</span>'
                )
                + '<span class="nm">'
                + esc(f.name)
                + '<br><small>'
                + sz(f.size)
                + '</small></span>'
                + (
                    im ? '<input type="date" data-k="'
                        + k
                        + '" data-i="'
                        + j
                        + '" data-d="1" value="'
                        + esc(f.tgl)
                        + '" aria-label="Tanggal foto"><input type="text" data-k="'
                        + k
                        + '" data-i="'
                        + j
                        + '" data-l="1" value="'
                        + esc(f.lok)
                        + '" placeholder="Lokasi foto" maxlength="80" aria-label="Lokasi foto">': ''
                )
                + '<button type="button" class="rm" data-k="'
                + k
                + '" data-i="'
                + j
                + '" aria-label="Hapus berkas">&times;</button></li>'
        }).join("")
    }

    function addF(k, files) {
        var x = st[k], er = [];

        [].forEach.call(files, function (f) {
            if (!OK.test(f.name)) {
                er.push(f.name + ": jenis berkas tidak didukung.");
                return
            }

            if (f.size > MAXB) {
                er.push(f.name + ": lebih dari 5 MB.");
                return
            }

            if (x.f.length >= MAXF) {
                er.push("Maksimal " + MAXF + " berkas per butir.");
                return
            }

            var o = { name: f.name, type: f.type, size: f.size, tgl: "", lok: "", url: "" };
            x.f.push(o);

            if (isImg(f)) {
                var r = new FileReader();

                r.onload = function () {
                    o.url = r.result;
                    if (x.f.indexOf(o) > -1) flist(k)
                };

                r.readAsDataURL(f)
            }
        });

        st[k].er = er.length ? er.join(" ") : "";
        flist(k);
        upd()
    }

    function clearF() {}

    function val(g, u) {
        var n = 0, s = 0, ok = 0;

        G[g][1][u][2].forEach(function (_, i) {
            if (na(g, u, i)) return;
            n++;
            var v = eff(g, u, i);
            s += v;
            if (v == 2) ok++
        });

        return { v: n ? s / (n * 2) * 100 : 0, n: n, ok: ok }
    }

    function avg(g) {
        var a = G[g][1].map(function (_, u) {
            return val(g, u).v
        });

        return { m: a.reduce(function (x, y) {
            return x + y
        }, 0) / a.length, mn: Math.min.apply(0, a) }
    }

    function kat(x) {
        return x >= 80 ? "Sangat Baik" : x >= 71 ? "Baik" : x >= 60 ? "Cukup" : "Kurang"
    }

    function kc(k) {
        return k == "Cukup" ? " m" : k == "Kurang" ? " l" : ""
    }

    function ig(b, s, k, t) {
        return .5 * b + .25 * s + .15 * k + .1 * t
    }

    function calc() {
        var b = avg(0),
            s = avg(1),
            k = val(2, 0).v,
            t = val(3, 0).v,
            y = $("#y1").checked,
            kz = [0, 1, 2].some(function (i) {
                return eff(2, 0, i) == 0
            });

        return {
            nb: b.m,
            ns: s.m,
            nk: k,
            nt: t,
            ig: ig(b.m, s.m, k, t),
            B: b.m >= 80 && b.mn >= 60,
            S: s.m >= (y ? 70 : 80) && s.mn >= (y ? 50 : 60),
            K: (y || k >= 80) && !kz
        }
    }

    function f(x) {
        return x.toFixed(1)
    }

    /*=============== ASSESSMENT FORM & EVIDENCE UPLOAD ===============*/
    function build() {
        var h = "";
        st = {};

        G.forEach(function (g, gi) {
            h += '<details class="grp"' + (gi ? '' : ' open') + '><summary>' + g[0] + '</summary>';

            g[1].forEach(function (u, ui) {
                if (g[1].length > 1) h += '<h4>' + u[0] + '</h4>';

                u[2].forEach(function (t, i) {
                    var k = gi + "." + ui + "." + i;
                    st[k] = { s: 0, f: [], o: "", er: "" };

                    h += '<div class="it" id="r' + k + '"><span>' + t + '</span><div class="seg" data-k="' + k + '">' + [
                        0,
                        1,
                        2
                    ].map(function (v) {
                        return '<button type="button" aria-pressed="'
                            + (v == 0)
                            + '" data-v="'
                            + v
                            + '">'
                            + v
                            + '</button>'
                    }).join("") + '</div><div class="ub"><label class="up"><input type="file" multiple accept="image/*,.pdf,.doc,.docx,.xls,.xlsx" data-f="' + k + '" aria-label="Unggah bukti dukung"> + Unggah bukti</label><input class="join__input obs" data-o="' + k + '" placeholder="Atau tulis hasil pengamatan (min. 10 karakter)" maxlength="300" aria-label="Hasil pengamatan"><ul class="fl" id="f' + k + '"></ul></div><div class="wn" id="w' + k + '"></div></div>'
                })
            });

            h += "</details>"
        });

        $("#forms").innerHTML = h;
        upd()
    }

    function upd() {
        var c = calc(), ev0 = 0, sc0 = 0;

        Object.keys(st).forEach(function (k) {
            if (st[k].s > 0) {
                sc0++;
                if (evOK(st[k])) ev0++
            }
        });

        Object.keys(st).forEach(function (k) {
            var p = k.split("."), t = na(+p[0], +p[1], +p[2]);
            document.getElementById("r" + k).style.opacity = t ? .45 : 1;

            document.getElementById("w" + k).textContent = t ? "Tidak berlaku: tanpa asrama, dapur, atau kantin." : (
                st[k].er ? st[k].er : (
                    st[k].s > 0 && !evOK(st[k]) ? (
                        st[k].f.length ? "Foto wajib memuat tanggal dan lokasi. Skor sementara dihitung 0." : "Tanpa bukti dukung, skor dihitung 0."
                    ) : ""
                )
            )
        });

        $("#res").innerHTML = [
            ["NB", c.nb],
            ["NS", c.ns],
            ["NK", c.nk],
            ["NT", c.nt],
            ["IGBS", c.ig]
        ].map(function (x) {
            return "<div><b>" + f(x[1]) + "</b><span>" + x[0] + "</span></div>"
        }).join("") + "<div><b>" + kat(c.ig) + "</b><span>Kategori</span></div><div><b>" + ev0 + " / " + sc0 + "</b><span>Butir berbukti</span></div>";

        $("#s1").textContent = f(c.ig);
        $("#s2").textContent = kat(c.ig);
        $("#s3").textContent = f(c.nb);
        $("#s4").textContent = f(c.ns);
        $("#s5").textContent = f(c.nk);
        $("#s6").textContent = f(c.nt);
        $("#sb").style.width = c.ig + "%";

        $("#sts").innerHTML = [["BARISAN", c.B], ["SIPAKAINGE", c.S], ["Kolaborasi", c.K]].map(function (
            x
        ) {
            return '<span class="pill'
                + (x[1] ? "" : " l")
                + '">'
                + x[0]
                + ": "
                + (x[1] ? "memenuhi" : "belum memenuhi")
                + "</span>"
        }).join("");

        $("#cards").innerHTML = G[0][1].map(function (u, ui) {
            var r = val(0, ui), p = Math.round(r.v);

            return '<article class="destination__card"><img src="'
                + u[1]
                + '" alt="" class="destination__img"><div class="destination__data"><h3 class="destination__subtitle">'
                + r.ok
                + ' / '
                + r.n
                + ' butir terpenuhi</h3><h2 class="destination__title">'
                + u[0]
                + '</h2><p class="destination__country"><b>'
                + p
                + '</b>&nbsp;nilai unsur'
                + (p < 60 ? ' &middot; di bawah ambang 60' : '')
                + '</p><div class="trk"><i style="width:'
                + p
                + '%"></i></div></div></article>'
        }).join("")
    }

    $("#forms").addEventListener("click", function (e) {
        var b = e.target.closest("button[data-v]");
        if (!b) return;
        var s = b.parentNode;
        st[s.dataset.k].s = +b.dataset.v;

        [].forEach.call(s.children, function (x) {
            x.setAttribute("aria-pressed", x == b)
        });

        upd()
    });

    $("#forms").addEventListener("change", function (e) {
        var t = e.target;

        if (t.dataset.f) {
            addF(t.dataset.f, t.files);
            t.value = ""
        }
    });

    $("#forms").addEventListener("input", function (e) {
        var t = e.target, d = t.dataset;

        if (d.o !== undefined) {
            st[d.o].o = t.value;
            upd()
        } else if (d.d) {
            st[d.k].f[+d.i].tgl = t.value;
            upd()
        } else if (d.l) {
            st[d.k].f[+d.i].lok = t.value;
            upd()
        }
    });

    $("#forms").addEventListener("click", function (e) {
        var b = e.target.closest(".rm");
        if (!b) return;
        st[b.dataset.k].f.splice(+b.dataset.i, 1);
        st[b.dataset.k].er = "";
        flist(b.dataset.k);
        upd()
    });

    $("#as").onchange = $("#y1").onchange = upd;

    $("#rs").onclick = function () {
        build();
        msg("Penilaian diatur ulang.", 1)
    };

    /*=============== SAVED ASSESSMENTS (STORAGE & TABLE) ===============*/
    function load() {
        try {
            return JSON.parse(localStorage.getItem(KEY)) || []
        } catch (e) {
            return mem
        }
    }

    function save(d) {
        mem = d;

        try {
            localStorage.setItem(KEY, JSON.stringify(d))
        } catch (e) {}
    }

    function esc(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]
        })
    }

    function msg(t, ok) {
        var m = $("#msg");
        m.textContent = t;
        m.style.color = ok ? "#1f8a5b" : "#d64545"
    }

    function vis(x) {
        return U && (U.role == "kanwil" || x.nm === U.sk)
    }

    function rows() {
        return load().filter(vis).map(function (x) {
            var g = ig(x.nb, x.ns, x.nk, x.nt);

            return Object.assign({
                ig: g, kt: kat(g)
            }, x)
        }).sort(function (a, b) {
            return b.tgl.localeCompare(a.tgl) || b.ig - a.ig
        })
    }

    function render() {
        var d = rows();

        $("#tb").innerHTML = d.map(function (x) {
            return '<tr><td>'
                + esc(x.tgl)
                + '</td><td><b>'
                + esc(x.nm)
                + '</b><br><small>'
                + esc(x.jn)
                + '</small></td><td>'
                + f(x.nb)
                + '</td><td>'
                + f(x.ns)
                + '</td><td>'
                + f(x.nk)
                + '</td><td>'
                + f(x.nt)
                + '</td><td><b>'
                + f(x.ig)
                + '</b></td><td><span class="pill'
                + kc(x.kt)
                + '">'
                + x.kt
                + '</span></td><td><button class="button line" data-id="'
                + x.id
                + '">Hapus</button></td></tr>'
        }).join("");

        $("#em").style.display = d.length ? "none" : "block"
    }

    $("#sv").onclick = function () {
        var n = $("#nm").value.trim();

        if (!n) {
            msg("Isi nama satuan kerja terlebih dahulu.", 0);
            $("#nm").focus();
            return
        }

        var c = calc(), d = load();

        d.push({
            nm: n, jn: $("#jn").value, nb: c.nb, ns: c.ns, nk: c.nk, nt: c.nt, tgl: new Date().toISOString().slice(
                0,
                10
            ), id: Date.now()
        });

        save(d);
        render();
        msg("Penilaian tersimpan di Daftar Penilaian.", 1)
    };

    $("#tb").addEventListener("click", function (e) {
        var b = e.target.closest("[data-id]");
        if (!b || !confirm("Hapus penilaian ini?")) return;

        save(load().filter(function (x) {
            return String(x.id) !== b.dataset.id
        }));

        render()
    });

    $("#clr").onclick = function () {
        if (rows().length && confirm("Hapus semua penilaian yang tampil?")) {
            save(load().filter(function (x) {
                return!vis(x)
            }));

            render()
        }
    };

    $("#demo").onclick = function () {
        var t = new Date().toISOString().slice(0, 10), d = load(), n = Date.now();

        [
            ["Kanwil Sulawesi Selatan", "Kanwil", 88, 82, 100, 92],
            ["Kankemenag Kota Makassar", "Kankemenag", 84, 78, 83, 100],
            ["MAN 2 Makassar", "MAN", 90, 85, 100, 100],
            ["Kankemenag Gowa", "Kankemenag", 79, 70, 67, 83],
            ["MTsN 3 Maros", "MTsN", 81, 74, 67, 92],
            ["KUA Tanete Riattang", "KUA", 68, 60, 50, 67],
            ["Kankemenag Luwu", "Kankemenag", 55, 48, 33, 50]
        ].forEach(function (x, i) {
            d.push({
                nm: x[0], jn: x[1], nb: x[2], ns: x[3], nk: x[4], nt: x[5], tgl: t, id: n + i
            })
        });

        save(d);
        render()
    };

    $("#csv").onclick = function () {
        var d = rows();

        if (!d.length) {
            alert("Belum ada data untuk diunduh.");
            return
        }

        function q(s) {
            s = String(s);
            if (/^[=+\-@]/.test(s)) s = "'" + s;
            return '"' + s.replace(/"/g, '""') + '"'
        }

        var r = [
            ["Tanggal", "Satuan Kerja", "Jenis", "NB", "NS", "NK", "NT", "IGBS", "Kategori"].map(q).join(
                ","
            )
        ].concat(d.map(function (x) {
            return [x.tgl, x.nm, x.jn, f(x.nb), f(x.ns), f(x.nk), f(x.nt), f(x.ig), x.kt].map(q).join(
                ","
            )
        }));

        var a = document.createElement("a");

        a.href = URL.createObjectURL(
            new Blob(["\ufeff" + r.join("\r\n")], { type: "text/csv;charset=utf-8" })
        );

        a.download = "si-barisan.csv";
        document.body.appendChild(a);
        a.click();
        a.remove()
    };

    /*=============== AUTHENTICATION (DEMO ACCOUNTS) ===============*/
    var AC = [{
        u: "kanwil", p: "kanwil123", n: "Tim Pelaksana Kanwil", role: "kanwil", sk: "Kanwil Sulawesi Selatan", jn: "Kanwil"
    }, {
        u: "kankemenag",
        p: "kab123",
        n: "Tim Pelaksana Kankemenag",
        role: "kab",
        sk: "Kankemenag Kota Makassar",
        jn: "Kankemenag"
    }, {
        u: "kua",
        p: "kua123",
        n: "Tim Pelaksana KUA",
        role: "unit",
        sk: "KUA Maros Baru",
        jn: "KUA"
    }, {
        u: "madrasah",
        p: "mdr123",
        n: "Tim Pelaksana Madrasah",
        role: "unit",
        sk: "MAN 2 Makassar",
        jn: "MAN"
    }],
        SK = "si-barisan-sesi",
        fails = 0,
        lockUntil = 0,
        msess = null;

    function getS() {
        try {
            return localStorage.getItem(SK) || msess
        } catch (e) {
            return msess
        }
    }

    function setS(v) {
        msess = v;

        try {
            v ? localStorage.setItem(SK, v) : localStorage.removeItem(SK)
        } catch (e) {}
    }

    function find(u) {
        return AC.filter(function (a) {
            return a.u === u
        })[0]
    }

    function enter(a) {
        U = a;
        $("#login").hidden = true;
        $("#app").hidden = false;
        $("#who").textContent = a.n + " - " + a.sk;
        var k = a.role == "kanwil";
        $("#nm").value = a.sk;
        $("#nm").readOnly = !k;
        $("#jn").value = a.jn;
        $("#jn").disabled = !k;
        $("#demo").style.display = k ? "" : "none";
        build();
        render();
        msg("", 1);
        window.scrollTo(0, 0)
    }

    function leave() {
        U = null;
        setS(null);
        $("#app").hidden = true;
        $("#login").hidden = false;
        $("#lf").reset();
        $("#lp").type = "password";
        $("#lerr").textContent = "";
        window.scrollTo(0, 0)
    }

    $("#lf").addEventListener("submit", function (e) {
        e.preventDefault();
        var er = $("#lerr"), now = Date.now();

        if (now < lockUntil) {
            er.textContent = "Terlalu banyak percobaan. Coba lagi dalam "
                + Math.ceil((lockUntil - now) / 1000)
                + " detik.";

            return
        }

        var u = $("#lu").value.trim().toLowerCase(), p = $("#lp").value;

        if (!u || !p) {
            er.textContent = "Isi nama pengguna dan kata sandi.";
            return
        }

        var a = find(u);

        if (!a || a.p !== p) {
            fails++;

            if (fails >= 5) {
                fails = 0;
                lockUntil = now + 30000;
                er.textContent = "Terlalu banyak percobaan. Coba lagi dalam 30 detik."
            } else er.textContent = "Nama pengguna atau kata sandi salah.";

            return
        }

        fails = 0;
        er.textContent = "";
        setS(a.u);
        $("#lp").value = "";
        enter(a)
    });

    $("#lshow").onchange = function () {
        $("#lp").type = this.checked ? "text" : "password"
    };

    $("#lacc").addEventListener("click", function (e) {
        var b = e.target.closest("[data-u]");
        if (!b) return;
        var a = find(b.dataset.u);
        $("#lu").value = a.u;
        $("#lp").value = a.p;
        $("#lerr").textContent = "";
        $("#lp").focus()
    });

    $("#lo").onclick = leave;
    var s0 = getS(), a0 = s0 && find(s0);
    if (a0) enter(a0);
    else leave();
})();
